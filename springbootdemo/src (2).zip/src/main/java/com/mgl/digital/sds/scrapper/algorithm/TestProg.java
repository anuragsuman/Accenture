package com.mgl.digital.sds.scrapper.algorithm;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mgl.digital.sds.scrapper.app.service.DefaultNumberService;
import com.mgl.digital.sds.scrapper.app.service.YourTargetNumberService;

public class TestProg {
	
	@Autowired
	private DefaultNumberService numberService = new DefaultNumberService();
	
	@Autowired 
	private YourTargetNumberService targetNumberService = new YourTargetNumberService();
	
	@Test
	public void targetNumber() throws Exception {
		Integer arr[] = {0, 29, 10, 8, 19, 2};
		Integer[] actualOutput = targetNumberService.indices(arr, 37);
		Integer[] expectedOutput = {1,3};
		assertEquals(actualOutput, expectedOutput);
	}
	
	@Test
	public void number() throws Exception {
		Integer arr[] = {0, 29, 10, 8, 19, 2};
		Map<String, Object> actualOutput = numberService.getNumbers();
		assert(actualOutput.toString().contains("[9, 25, 36, 81, 100, 144, 225, 324, 400, 441]"));
	}
}
