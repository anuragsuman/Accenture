package com.mgl.digital.sds.scrapper.app.service;

public interface TargetNumberService {
    Integer[] indices(Integer[] arr, int target) throws Exception;
}