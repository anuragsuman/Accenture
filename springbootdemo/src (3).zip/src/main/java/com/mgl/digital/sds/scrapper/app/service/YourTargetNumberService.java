package com.mgl.digital.sds.scrapper.app.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class YourTargetNumberService implements TargetNumberService {
    
    @Override
    public Integer[] indices(Integer[] arr, int target) throws Exception{
    	Map<Integer,Integer> numMap = new HashMap<Integer,Integer>();
    	try {
    		for(int i =0; i<arr.length;i++) {
    			//target=37, find the index of the complement element.
    			int complement = target - arr[i];
    			//finding the index and put into the map
    			if(numMap.containsKey(complement)) {
    				return new Integer[] {numMap.get(complement),i};
    			}else {
    				numMap.put(arr[i], i);
    			}
    		}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	return new Integer[] {};
    }
}