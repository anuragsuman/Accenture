package com.mgl.digital.sds.scrapper.app.service;

import java.util.*;
import java.util.stream.*;

import org.springframework.stereotype.Service;

@Service
public class DefaultNumberService implements NumberService {
  
    @Override
    public Map<String, Object> getNumbers() throws Exception{
    	long startTime = System.nanoTime();
    	Map<String, Object> response = new HashMap<>();
    	try {
    		//Range the data from 1 to 1001 and filter it of multiple of 3 or 5 and square the number. 
    		List<Integer> result = IntStream.range(1, 1001).boxed().
    				filter(i -> i % 3 == 0 || i % 5 == 0).map(e->e*e).limit(10).collect(Collectors.toList());
    		//add result and time_taken to the response.
    		response.put("data", result);
    		response.put("time_taken", System.nanoTime()-startTime);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
        return response;
    }
}