package com.example.Program1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program1Application {

	public static void main(String[] args) {
		SpringApplication.run(Program1Application.class, args);
	}

}
